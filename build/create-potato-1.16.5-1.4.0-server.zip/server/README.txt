Thank you for downloading Create Potato server!

1. To install forge, read "How To Install Servers" by  Kreezxil at: 
https://kreezcraft.com/info__trashed/servers/how-to-install-servers/

2. The link to the correct forge download is found in: CURRENT_INSTALLER

3. To start the server:
 - Linux or Mac, open a command prompt and navigate to this folder and execute the file run.sh
 - Windows you can double click the "forge[version].jar" and your server will power up

4. You will then need to open the EULA and change from eula=false to eula=true

Please visit our discord at: https://discord.com/invite/jXrx4Tu

Thank you and have fun!
ClaudiusMinimus