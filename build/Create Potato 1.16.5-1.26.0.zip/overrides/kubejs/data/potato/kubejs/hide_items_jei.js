onEvent('jei.hide.items', jei => {

    jei.hide([
        'forbidden_arcanus:bone_hoe'
    ])
})